"""C2F4DT core package."""
__all__ = ["app"]
