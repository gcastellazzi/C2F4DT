# Rendiamo importabile il package "plugins.example_display_button"
# (non è strettamente necessario, ma è pulito esporre register)
# from .plugin import register  # noqa: F401