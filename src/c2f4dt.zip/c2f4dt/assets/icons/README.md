# Icons

Place your 32x32 / 64x64 PNG icons here. The code will reference them by filename.
